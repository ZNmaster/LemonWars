#include <iostream>
#include <fstream>
#include <cstring>
#include <string>

#include "Init.ini"
#include "MemoryBuilder.h"
#include "LevelData.h"




int main()
{

    //MemoryBuilder aaa;

    LevelData level1;
    strncpy(level1.filename,"level1.dat", 60);

    std::cout << level1.filename <<  std::endl;

    std::fstream myFile2;
    myFile2.open(level1.filename, std::ios::in | std::ios::binary);

    myFile2.read((char *)&level1, sizeof(LevelData));

    myFile2.close();

    for(int16_t to_ = 0; to_ < level1.number_of_points; to_ ++)
    {
        for(int16_t from_ = 0; from_ < level1.number_of_points; from_ ++)
        {

            //level1.path[a][b] = path[a][b];
            std::cout << level1.distance[to_][from_] << " ";
        }
        std::cout << std::endl;
    }
    strncpy(level1.filename,"level1.dat", 60);

    std::string str = level1.filename;

    std::cout << str <<  std::endl;






  return 0;



}

