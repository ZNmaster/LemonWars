#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include "Gamebooter.h"
#include "Init.ini"
#include "Navigator.h"



int main()
{

  Navigator newone("testlevel.dat");

  newone.Create();






  /*int distance[150][150];

  int (*dist_ptr)[150][150];

  dist_ptr = &distance;
  (*dist_ptr)[0][0] = 12345;

  std::cout << distance[0][0];*/






  return 0;



}

