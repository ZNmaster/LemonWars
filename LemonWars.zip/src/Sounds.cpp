#include "Sounds.h"

Sounds::Sounds()
{


}

void Sounds::play_fire_sound()
{

}

void Sounds::play_projectile_explosion_sound()
{

}
void Sounds::play_floating_lemon_hit()
{

}

void Sounds::play_lemonade()
{

}

void Sounds::play_lemon_juice()
{

}

void Sounds::play_ezpz()
{

}

void Sounds::play_beep()
{

}

void Sounds::play_beep2()
{

}


Sounds::~Sounds()
{
    //dtor
}
