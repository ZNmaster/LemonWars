#include "Title.h"
#include <iostream>

Title::Title()
{
    //ctor
}

Title::~Title()
{
    //dtor
}

void Title::go_move()
{
std::cout << "move of Title" << std::endl;
}
