#include "vita2d_texture.h"

vita2d_texture::vita2d_texture()
{
    //ctor
}

vita2d_texture::~vita2d_texture()
{
    //dtor
}
