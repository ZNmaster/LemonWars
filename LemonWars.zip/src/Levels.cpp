#include "Menu.h"
#include "Game.h"


void Menu::level1_1()
{
    Game level1_1("app0:/assets/images/levels/1_1/Level1_1.png", "app0:/assets/memory/level1.dat");
    bool gameover = level1_1.StartGame();


}
