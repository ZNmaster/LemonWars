#include "Geometry.h"

EPoint_int::EPoint_int()
{
    //ctor
}

EPoint_int::EPoint_int(unsigned int x1, unsigned int y1)
{
    x = x1;
    y = y1;
    //ctor
}

EPoint_float::EPoint_float()
{
    //ctor
}

EPoint_float::EPoint_float(float x1, float y1) //: x (x), y (y)
{
    x = x1;
    y = y1;
    //ctor
}
