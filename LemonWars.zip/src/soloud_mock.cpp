#include "soloud.h"
#include "soloud_wavstream.h"
#include "soloud_wav.h"

#include <iostream>

SoLoud::Soloud::Soloud()
{

}

SoLoud::WavStream::WavStream()
{

}

SoLoud::AlignedFloatBuffer::AlignedFloatBuffer()
{

}

SoLoud::Fader::Fader()
{

}

SoLoud::AudioSourceInstance3dData::AudioSourceInstance3dData()
{

}

SoLoud::AlignedFloatBuffer::~AlignedFloatBuffer()
{

}

SoLoud::AudioSource::AudioSource()
{

}

SoLoud::Wav::Wav()
{

}

SoLoud::result SoLoud::Soloud::init(unsigned int aFlags, unsigned int aBackend, unsigned int aSamplerate, unsigned int aBufferSize, unsigned int aChannels)
{
  return 1;
}


