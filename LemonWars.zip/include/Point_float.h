#ifndef POINT_FLOAT_H
#define POINT_FLOAT_H

struct Point_float

{
   float x;
   float y;
   
};

#endif // POINT_FLOAT_H
