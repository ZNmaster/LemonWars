#ifndef LEVELDATA_H
#define LEVELDATA_H
#include <cstdint>

struct LevelData

{
    //the number of nav points on the map
    int number_of_points;

    //coordinates of the nav points on the map
    int16_t coord_x[150];
    int16_t coord_y[150];

    //distance between the nav points
    int16_t distance[150][150];

    //path between the nav points
    int16_t path[150][150];

    //wall coordinates
    int16_t wall_x_start[70];
    int16_t wall_y_start[70];
    int16_t wall_x_end[70];
    int16_t wall_y_end[70];

    //map image filename
    char filename[60];

};

#endif // LEVELDATA_INCLUDED
