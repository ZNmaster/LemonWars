#ifndef POINT_INT_H
#define POINT_INT_H

struct Point_int

{
   unsigned int x;
   unsigned int y;
   
};

#endif // POINT_INT_H
