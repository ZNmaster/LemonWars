/**
 * \usergroup{SceDefs}
 * \usage{psp2/defs.h}
 */


#ifndef _PSP2_DEFS_H_
#define _PSP2_DEFS_H_

#define PSP2_SDK_VERSION 0x03570011

#endif /* _PSP2_DEFS_H_ */
