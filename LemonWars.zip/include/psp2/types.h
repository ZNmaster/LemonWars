/**
 * \usergroup{SceTypes}
 * \usage{psp2/types.h}
 */


#ifndef _PSP2_TYPES_H_
#define _PSP2_TYPES_H_

#include <psp2common/types.h>

#endif /* _PSP2_TYPES_H_ */
