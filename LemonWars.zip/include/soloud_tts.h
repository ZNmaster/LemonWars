
extern int xlate_string (const char *string,darray *phone);


	
