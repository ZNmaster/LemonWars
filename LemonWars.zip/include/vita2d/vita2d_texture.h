#ifndef VITA2D_TEXTURE_H
#define VITA2D_TEXTURE_H


/*
class vita2d_texture
{
    public:
        vita2d_texture();
        virtual ~vita2d_texture();

    protected:

    private:
};

class vita2d_pvf
{
    public:
        vita2d_pvf();
        virtual ~vita2d_pvf();

    protected:

    private:
};
*/

#endif // VITA2D_TEXTURE_H
